# CSV to MYSQL loader (python project)
## About
This python script automatically reads data from csv file and uploads it into a MYSQL database.
It's useful for automating data entry tasks in business such as HR, sales, or Inventory systems.
## Technologies used 
-Python
-Pandas 
-My SQL connector
-My SQL database

## How to run 
1. intall dependencies:
(pip install mysql-connector-python pandas)
2. Edit databse connection in the script 
3. Run:
(python csv_to_mysql.py)
input: 'employees.csv'
output: Data inserted succesfully into MYSQL table