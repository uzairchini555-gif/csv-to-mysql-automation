import pandas as pd
import mysql.connector
data = pd.read_csv("employees.csv")
connection = mysql.connector.connect(
    host="localhost",
    user="root",
    password="Chini@825",
    database="company_db"
)
cursor=connection.cursor()
for _, row in data.iterrows():
    cursor.execute("INSERT INTO employees (name, age, salary) VALUES (%s,%s, %s)",(row['name'],row['age'],row['salary'])
                   )
    connection.commit()
    print("Data inserted successfully!")